// Ensure JS runs after the DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
  console.log('Portfolio initialized successfully!');

  // Example: Smooth scroll behavior for internal anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const targetId = this.getAttribute('href');
      if (targetId === '#') return;
      
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        targetElement.scrollIntoView({
          behavior: 'smooth'
        });
      }
    });
  });
});
